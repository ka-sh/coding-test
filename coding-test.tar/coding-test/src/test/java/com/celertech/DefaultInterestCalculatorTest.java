package com.celertech;

import org.testng.AssertJUnit;
import org.testng.annotations.Test;

import com.celertech.exceptions.InvalidAmountException;

public class DefaultInterestCalculatorTest {
	@Test
	public void testRatesFor100KOrLess() throws InvalidAmountException{
		AssertJUnit.assertEquals(1.5d, new DefaultInterestCalculator().cal(90000d));
		AssertJUnit.assertEquals(1.5d, new DefaultInterestCalculator().cal(100000d));
	}
	@Test
	public void testRatesFor200KOrLess() throws InvalidAmountException{
		AssertJUnit.assertEquals(1.4d, new DefaultInterestCalculator().cal(190000d));
		AssertJUnit.assertEquals(1.4d, new DefaultInterestCalculator().cal(200000d));
	}
	@Test
	public void testRatesFor300KOrLess() throws InvalidAmountException{
		AssertJUnit.assertEquals(1.3d, new DefaultInterestCalculator().cal(290000d));
		AssertJUnit.assertEquals(1.3d, new DefaultInterestCalculator().cal(300000d));
	}
	@Test
	public void testRatesForOver300K() throws InvalidAmountException{
		AssertJUnit.assertEquals(1.5d, new DefaultInterestCalculator().cal(390000d));
	}
	@Test(expectedExceptions=InvalidAmountException.class)
	public void testRatesForInvalidAmount() throws InvalidAmountException{
		AssertJUnit.assertEquals(1.5d, new DefaultInterestCalculator().cal(0d));
	}
	
}