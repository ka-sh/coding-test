package com.celertech;

import javax.activity.InvalidActivityException;

import com.celertech.domain.DefaultInterestRate;
import com.celertech.exceptions.InvalidAmountException;
/**
 * I wouldn't favor utility classes that are tight up to the business logic. 
 * Utility classes usually indicate the use of static methods, which once software scale if they are tight to business logic they will be hard to change.
 * I would prefer the use of composition for that example to give my self the freedom to change/re-factor in the future.
 *
 */
public class DefaultInterestCalculator implements InterestCalculator{
	// Scenario
	// ------------
	// A trader has phoned up telling us the interest rate he is getting based
	// on a loan
	// amount of 200K is wrong. Please investigate

	/**
	 * Calculates the interest rate band based on the amount.
	 * 
	 * Confirmed Business Rules are:
	 * 
	 * If the amount is 100K or Less return 1.5 If the amount is 200K or Less
	 * return 1.4 If the amount is 300K or Less return 1.3 Otherwise return 1.5
	 * 
	 * @param a
	 *            the amount
	 * 
	 * @return double interest rate
	 * @throws InvalidActivityException 
	 */
	@Override
	public double cal(double amount) throws InvalidAmountException {
		/**
		 * I am not sure about the business case, but I will assume that amounts
		 * that are equal to or less than 0 are not permitted.
		 */
		if(!isValidAmount(amount)){
			throw new InvalidAmountException("Invalid amount value : "+amount);
		}
		for(DefaultInterestRate interestRate:DefaultInterestRate.values()){
			if(amount <=interestRate.amount()){
				return interestRate.rate();
			}
		}
		return DefaultInterestRate.other();
	}
	/**
	 * Validate amount
	 * @param amount
	 * @return
	 */
	public boolean isValidAmount(double amount){
		return amount>0;
	}
}
