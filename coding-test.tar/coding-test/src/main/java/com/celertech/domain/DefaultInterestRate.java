package com.celertech.domain;

/*
 * Contains current default interest rates.
 */
public enum DefaultInterestRate {
	LESS_OR_EQUAL_100K(1.5d, 100000d), LESS_OR_EQUAL_200K(1.4d, 200000d), LESS_OR_EQUAL_300K(
			1.3d, 300000d);
	private double interest;
	private double amount;

	private DefaultInterestRate(double interest, double amount) {
		this.interest = interest;
		this.amount = amount;
	}

	public double rate() {
		return interest;
	}

	public double amount() {
		return amount;
	}
	/**
	 * Return interest rates that doesn't fall within the expected range.
	 * @return
	 */
	public static double other(){
		return 1.5d;
	}
}
