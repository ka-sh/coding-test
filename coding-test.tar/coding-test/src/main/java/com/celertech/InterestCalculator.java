package com.celertech;

import javax.activity.InvalidActivityException;

import com.celertech.exceptions.InvalidAmountException;

public interface InterestCalculator {
	/**
	 * Calculates the interest rate band based on the amount.
	 * 
	 * @param amount
	 *            to calculate interest rate for.
	 * @return interest rate.
	 * @throws InvalidActivityException If amount is equal to or less than 0.
	 */
	double cal(double amount)throws InvalidAmountException, InvalidActivityException;
}
